Objetivo del Sitio:
El sitio web PagesBook aputa a ser una comunidad en la cual los usuarios 
puedan descargar, leer online, adjuntar nuevos libros, guardarlos en su portafolio libros
los cuales desean leer luego y tambien mantenerse al tanto de las novedades de nuevos ingresos
en Uuruguay.

Funcionalidades a la fecha (11/10/2020)

			- Index ( Pagina principal de el sitio )

-Cuenta actualmente en funcionamiento con los link de crear usuario e iniciar sesión ( angulo superior derecho).
	para volver al inicio solo hay que hacer clic en la opcion "HOME" del menu.
- Link de novedades en cada libro que allí esta comprendido.
	Esto cuenta con la ruta absoluta y nos llevara a la pagina para tener información de compra.
- Dentro de la sección "Mas Vistos":
	-Aqui estaran los libros más vistos del sitio al momento
	-En las cards (cuentan con animación) que tienen el icono de descarga se podra hacer click en su nombre
	 y esto desplegara el link correspondiente para leer online.
-Footer:
	-Aqui estan comprendidas nuestras redes sociales con su correspondientes link's. 
	-Nuestro e-mail de contacto
	-Información que respalda la fuente de las noticias de libros que ingrersan al pais.(link)
	-una sección de "Ayuda al Usuario" y otra de "Avisos Legales". (en mantenimiento) (link)	 